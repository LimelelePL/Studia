from enum import Enum, IntEnum
from typing import Final

from app.logs_parser.my_types import Entry

EMPTY_FIELD: Final = "-"


# this enum is iterable, this class must have exaclty the same number of entres as EntryIndex
# in order to keep sort_log working
class RawLogIndex(IntEnum):
    TS = 0
    UID = 1
    ORIG_H = 2
    ORIG_P = 3
    RESP_H = 4
    RESP_P = 5
    METHOD = 7
    HOST = 8
    URI = 9
    STATUS_CODE = 14
    SIZE = 13


class EntryIndex:
    TS: Final = 0
    UID: Final = 1
    ORIG_H: Final = 2
    ORIG_P: Final = 3
    RESP_H: Final = 4
    RESP_P: Final = 5
    METHOD: Final = 6
    HOST: Final = 7
    URI: Final = 8
    STATUS_CODE: Final = 9
    SIZE: Final = 10
    DATE: Final = 11
    TIME: Final = 12
    TIMEZONE: Final = 13


class EntryDictKey:
    TS: Final = "ts"
    UID: Final = "uid"
    ORIG_H: Final = "orig_h"
    ORIG_P: Final = "orig_p"
    RESP_H: Final = "resp_h"
    RESP_P: Final = "resp_p"
    METHOD: Final = "method"
    HOST: Final = "host"
    URI: Final = "uri"
    STATUS_CODE: Final = "status_code"
    SIZE: Final = "size"
    DATE: Final = "date"
    TIME: Final = "time"
    TIMEZONE: Final = "timezone"


ENTRY_KEYS_WITH_IP: Final = (EntryDictKey.HOST, EntryDictKey.ORIG_H, EntryDictKey.RESP_H)

ENTRY_INDEXES_WITH_IP: Final = (EntryIndex.ORIG_H, EntryIndex.RESP_H, EntryIndex.HOST)
DETAIL_ENTRY_FIELDS: Final = (
    EntryIndex.ORIG_H,
    EntryIndex.DATE,
    EntryIndex.TIME,
    EntryIndex.TIMEZONE,
    EntryIndex.STATUS_CODE,
    EntryIndex.METHOD,
    EntryIndex.URI,
    EntryIndex.SIZE,
)

RAW_LOG_FIELD_INDEXES: Final = tuple(RawLogIndex)

EMPTY_ENTRY = Entry(None, None, None, None, None, None, None, None, None, None, None, None, None, None)


class HttpMethods(Enum):
    GET = "GET"
    PUT = "PUT"
    POST = "POST"
    DELETE = "DELETE"
